# HA2 Experiment Summary

- experiment: `experiments\ha2_000022_20260514_1907_combat-v1_500k`
- training_profile: `combat_v1`
- total_timesteps: `500000`
- seed: `0`
- n_envs: `8`
- vec_env: `dummy`
- train_eval: `on`
- eval_vec_env: `dummy`
- effective_eval_vec_env: `dummy`
- eval_freq: `1000`
- train_eval_episodes: `5`
- device: `auto`
- tensorboard_log: `experiments\ha2_000022_20260514_1907_combat-v1_500k\tensorboard`
- latest_model: `experiments\ha2_000022_20260514_1907_combat-v1_500k\models\latest.zip`
- best_model: `experiments\ha2_000022_20260514_1907_combat-v1_500k\models\best.zip`
- checkpoints: `experiments\ha2_000022_20260514_1907_combat-v1_500k\models\checkpoints`
- reports: `experiments\ha2_000022_20260514_1907_combat-v1_500k\reports`
- replays: `experiments\ha2_000022_20260514_1907_combat-v1_500k\replays`


## Evaluation Results (10 episodes)

| Metric | Best Model | Latest Model |
|---|---|---|
| Mean Reward | 187.20 | 160.63 |
| Mean Length | 1800.00 | 1618.40 |
| Mean Heli Kills | 8.30 | 7.30 |
| Mean Player Damage | 63.00 | 72.00 |
| Mean Final Score | 2680.00 | 2403.00 |
| Hit Rate | 77.82% | 78.35% |
| Death Rate | 0.00% | 20.00% |
| Timeout Rate | 100.00% | 80.00% |
