# HA2 Experiment Summary

- experiment: `experiments\ha2_000021_20260514_1828_combat-v1_500k`
- training_profile: `combat_v1`
- total_timesteps: `500000`
- seed: `0`
- n_envs: `4`
- vec_env: `dummy`
- train_eval: `on`
- eval_vec_env: `dummy`
- effective_eval_vec_env: `dummy`
- eval_freq: `1000`
- train_eval_episodes: `5`
- device: `auto`
- tensorboard_log: `experiments\ha2_000021_20260514_1828_combat-v1_500k\tensorboard`
- latest_model: `experiments\ha2_000021_20260514_1828_combat-v1_500k\models\latest.zip`
- best_model: `experiments\ha2_000021_20260514_1828_combat-v1_500k\models\best.zip`
- checkpoints: `experiments\ha2_000021_20260514_1828_combat-v1_500k\models\checkpoints`
- reports: `experiments\ha2_000021_20260514_1828_combat-v1_500k\reports`
- replays: `experiments\ha2_000021_20260514_1828_combat-v1_500k\replays`


## Evaluation Results (10 episodes)

| Metric | Best Model | Latest Model |
|---|---|---|
| Mean Reward | 190.60 | 173.84 |
| Mean Length | 1800.00 | 1794.30 |
| Mean Heli Kills | 8.60 | 7.90 |
| Mean Player Damage | 61.00 | 65.00 |
| Mean Final Score | 2714.00 | 2508.00 |
| Hit Rate | 79.92% | 74.80% |
| Death Rate | 0.00% | 10.00% |
| Timeout Rate | 100.00% | 90.00% |
